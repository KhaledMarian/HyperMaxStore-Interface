﻿using System;

using System.Data;

using System.Data.SqlClient;

using System.Windows.Forms;

namespace HyperMaxStore_Snacks_And_Chips_Module

{

    public partial class Form1 : Form

    {

        SqlConnection con = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=HyperMax_Snacks_And_Chips_Module;Integrated Security=True");

        public Form1()

        {

            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)

        {

            LoadProducts();

            LoadCategories();

            LoadSuppliers();

        }

        void LoadProducts()

        {

            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT P.Product_ID, P.Product_Name, P.Price, P.Quantity_in_stock, " +
                "P.Size, P.Expiry_Date, C.Category_Name, S.Supplier_Name " +
                "FROM Product P " +
                "INNER JOIN Category C ON P.Category_ID = C.Category_ID " +
                "INNER JOIN Supplier S ON P.Supplier_ID = S.Supplier_ID",
                con); 

            DataTable dt = new DataTable();

            da.Fill(dt);

            dgvProducts.DataSource = dt;

        }

        void LoadCategories()

        {

            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Category", con);

            DataTable dt = new DataTable();

            da.Fill(dt);

            cmbCategory.DataSource = dt;

            cmbCategory.DisplayMember = "Category_Name";

            cmbCategory.ValueMember = "Category_ID";

        }

        void LoadSuppliers()

        {

            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Supplier", con);

            DataTable dt = new DataTable();

            da.Fill(dt);

            cmbSupplier.DataSource = dt;

            cmbSupplier.DisplayMember = "Supplier_Name";

            cmbSupplier.ValueMember = "Supplier_ID";

        }

        private void btnSave_Click(object sender, EventArgs e)

        {

            if (txtProductName.Text == "" || txtPrice.Text == "" || txtQuantity.Text == "" || txtSize.Text == "")

            {

                MessageBox.Show("Please fill all fields!");

                return;

            }

            string query = "INSERT INTO Product (Product_Name, Price, Quantity_in_stock, Size, Expiry_Date, Category_ID, Supplier_ID) VALUES (@name, @price, @qty, @size, @expiry, @catID, @supID)";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@name", txtProductName.Text);

            cmd.Parameters.AddWithValue("@price", Convert.ToDecimal(txtPrice.Text));

            cmd.Parameters.AddWithValue("@qty", Convert.ToInt32(txtQuantity.Text));

            cmd.Parameters.AddWithValue("@size", txtSize.Text);

            cmd.Parameters.AddWithValue("@expiry", dtpExpiry.Value);

            cmd.Parameters.AddWithValue("@catID", cmbCategory.SelectedValue);

            cmd.Parameters.AddWithValue("@supID", cmbSupplier.SelectedValue);

            con.Open();

            cmd.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Product added successfully!");

            LoadProducts();

            ClearFields();

        }

        private void btnUpdate_Click(object sender, EventArgs e)

        {

            if (txtProductName.Text == "" || txtPrice.Text == "" || txtQuantity.Text == "" || txtSize.Text == "")

            {

                MessageBox.Show("Please select a product and fill all fields!");

                return;

            }

            string query = "UPDATE Product SET Product_Name=@name, Price=@price, Quantity_in_stock=@qty, Size=@size, Expiry_Date=@expiry, Category_ID=@catID, Supplier_ID=@supID WHERE Product_ID=@id";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgvProducts.CurrentRow.Cells[0].Value));

            cmd.Parameters.AddWithValue("@name", txtProductName.Text);

            cmd.Parameters.AddWithValue("@price", Convert.ToDecimal(txtPrice.Text));

            cmd.Parameters.AddWithValue("@qty", Convert.ToInt32(txtQuantity.Text));

            cmd.Parameters.AddWithValue("@size", txtSize.Text);

            cmd.Parameters.AddWithValue("@expiry", dtpExpiry.Value);

            cmd.Parameters.AddWithValue("@catID", cmbCategory.SelectedValue);

            cmd.Parameters.AddWithValue("@supID", cmbSupplier.SelectedValue);

            con.Open();

            cmd.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Product updated successfully!");

            LoadProducts();

            ClearFields();

        }

        private void btnDelete_Click(object sender, EventArgs e)

        {

            if (dgvProducts.CurrentRow == null)

            {

                MessageBox.Show("Please select a product to delete!");

                return;

            }

            string query = "DELETE FROM Product WHERE Product_ID=@id";

            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgvProducts.CurrentRow.Cells[0].Value));

            con.Open();

            cmd.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Product deleted successfully!");

            LoadProducts();

            ClearFields();

        }

        private void btnClear_Click(object sender, EventArgs e)

        {

            ClearFields();

        }

        void ClearFields()

        {

            txtProductName.Text = "";

            txtPrice.Text = "";

            txtQuantity.Text = "";

            txtSize.Text = "";

            dtpExpiry.Value = DateTime.Now;

        }

        private void dgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)

        {

            if (e.RowIndex >= 0)

            {

                txtProductName.Text = dgvProducts.Rows[e.RowIndex].Cells[1].Value.ToString();

                txtPrice.Text = dgvProducts.Rows[e.RowIndex].Cells[2].Value.ToString();

                txtQuantity.Text = dgvProducts.Rows[e.RowIndex].Cells[3].Value.ToString();

                txtSize.Text = dgvProducts.Rows[e.RowIndex].Cells[4].Value.ToString();

                dtpExpiry.Value = Convert.ToDateTime(dgvProducts.Rows[e.RowIndex].Cells[5].Value);

                cmbCategory.Text = dgvProducts.Rows[e.RowIndex].Cells[6].Value.ToString();

                cmbSupplier.Text = dgvProducts.Rows[e.RowIndex].Cells[7].Value.ToString();

            }

        }

        private void label6_Click(object sender, EventArgs e)

        {

        }

    }

}
