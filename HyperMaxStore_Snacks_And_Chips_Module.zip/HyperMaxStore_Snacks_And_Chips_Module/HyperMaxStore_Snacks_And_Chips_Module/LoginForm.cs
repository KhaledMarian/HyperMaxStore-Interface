﻿using System;
using System.Windows.Forms;

namespace HyperMaxStore_Snacks_And_Chips_Module
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            // Validation: Empty username
            if (txtUsername.Text == "")
            {
                MessageBox.Show("Please enter your username!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validation: Empty password
            if (txtPassword.Text == "")
            {
                MessageBox.Show("Please enter your password!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // StoreManager Access (Full Permissions)
            if (txtUsername.Text == "StoreManager" && txtPassword.Text == "HyperMax2026!")
            {
                MessageBox.Show("Login successful!\nRole: Store Manager\nAccess: Full Permissions", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form1 productForm = new Form1();
                productForm.Text = "Hyper Max Store - Manager (Full Access)";
                productForm.Show();
                this.Hide();
            }
            // Cashier Access (Limited)
            else if (txtUsername.Text == "Cashier" && txtPassword.Text == "Cashier2026!")
            {
                MessageBox.Show("Login successful!\nRole: Cashier\nAccess: Limited Permissions", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form1 productForm = new Form1();
                productForm.Text = "Hyper Max Store - Cashier (Limited Access)";
                productForm.Show();
                this.Hide();
            }
            // Wrong Password (Validation)
            else if (txtUsername.Text == "StoreManager" || txtUsername.Text == "Cashier")
            {
                MessageBox.Show("Wrong password! Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Text = "";
                txtPassword.Focus();
            }
            // Invalid username
            else
            {
                MessageBox.Show("Invalid username! Please use a valid account.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsername.Text = "";
                txtPassword.Text = "";
                txtUsername.Focus();
            }
        }
    }
}