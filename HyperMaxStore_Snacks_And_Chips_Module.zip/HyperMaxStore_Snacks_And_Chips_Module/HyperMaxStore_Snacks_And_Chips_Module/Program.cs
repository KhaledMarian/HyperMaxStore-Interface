﻿using System;
using System.Windows.Forms;

namespace HyperMaxStore_Snacks_And_Chips_Module
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());
        }
    }
}